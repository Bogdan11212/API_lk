"use strict";

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use("Schema");

class LinkSchema extends Schema {
  up() {
    this.create("links", (table) => {
      table.increments();
      table.integer("user_id").notNullable();
      table.string("upc").notNullable().unique();
      table.string("token").notNullable();
      table.string("apple");
      table.string("vk");
      table.string("yandex");
      table.string("youtube");
      table.string("spotify");
      table.string("deezer");
      table.string("social_vk");
      table.string("social_telegram");
      table.string("social_zen");
      table.string("social_tiktok");
      table.string("social_youtube");
      table.timestamps();
    });
  }

  down() {
    this.drop("links");
  }
}

module.exports = LinkSchema;
