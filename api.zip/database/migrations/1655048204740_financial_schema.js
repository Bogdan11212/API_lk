"use strict";

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use("Schema");

class FinancialSchema extends Schema {
  up() {
    this.create("financials", (table) => {
      table.increments();
      table.integer("user_id");
      table.integer("quarter");
      table.string("year");
      table.string("file");
      table.string("sum");
      table.timestamps();
    });
  }

  down() {
    this.drop("financials");
  }
}

module.exports = FinancialSchema;
