"use strict";

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use("Schema");

class StreamSchema extends Schema {
  up() {
    this.create("streams", (table) => {
      table.increments();
      table.integer("user_id").notNullable();
      table.integer("release_id").notNullable();
      table.string("title").notNullable();
      table.string("artists").notNullable();
      table.integer("pay_streams");
      table.integer("all_streams");
      table.string("upc").notNullable();
      table.date("date").notNullable();
      table.timestamps();
    });
  }

  down() {
    this.drop("streams");
  }
}

module.exports = StreamSchema;
