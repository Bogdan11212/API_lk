"use strict";

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use("Schema");

class AnalyticsSchema extends Schema {
  up() {
    this.create("analytics", (table) => {
      table.increments();
      table.integer("user_id").notNullable();
      table.integer("release_id").notNullable();
      table.string("title").notNullable();
      table.string("artists").notNullable();
      table.integer("pay_streams");
      table.integer("all_streams");
      table.string("upc").unique();
      table.timestamps();
    });
  }

  down() {
    this.drop("analytics");
  }
}

module.exports = AnalyticsSchema;
