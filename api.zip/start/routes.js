"use strict";

/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Http routes are entry points to your web application. You can create
| routes for different URL's and bind Controller actions to them.
|
| A complete guide on routing is available here.
| http://adonisjs.com/docs/4.1/routing
|
*/

/** @type {typeof import('@adonisjs/framework/src/Route/Manager')} */
const Route = use("Route");

const Env = use("Env");

Route.get("/", async ({ response }) => {
  return response.route("/status");
});
Route.get("/status", async () => {
  return { error: false, version: Env.get("VERSION") };
});

Route.get("/link_sync", "LinkController.sync");
Route.get("/get_link", "LinkController.get_link_web");
Route.get("/next/get_links", "LinkController.next_links");

Route.post("/get_analytics", "AnalyticsController.get_new_analytics");
Route.post("/get_streams", "AnalyticsController.get_new_streams");

// public
Route.group(() => {
  Route.post("/feedback", "PublicController.feedback");
  Route.post("/questionnaire", "PublicController.questionnaire");
}).prefix("/public");

// auth

Route.group(() => {
  Route.post("/login", "AuthController.login");
}).prefix("/auth");

// need auth

Route.group(() => {
  Route.get("/profile_info", "UserController.profile_info");
  Route.post("/edit_profile", "UserController.edit_profile");

  Route.get("/get_news", "NewsController.get_news");
  Route.get("/get_news_by_id", "NewsController.get_news_by_id");

  Route.get("/get_release_info", "ReleaseController.get_release_info");
  Route.get("/get_release_cover", "ReleaseController.get_release_cover");
  Route.get("/get_releases", "ReleaseController.get_releases");
  Route.post("/new_release", "ReleaseController.new_release");
  Route.post("/edit_release", "ReleaseController.edit_release");
  Route.post("/send_release", "ReleaseController.send_release");
  Route.post("/delete_draft", "ReleaseController.delete_draft");
  Route.post("/delete_release", "ReleaseController.delete_release");
  Route.get(
    "/get_release_platforms",
    "ReleaseController.get_release_platforms"
  );
  Route.get("/search", "ReleaseController.search");
  Route.get("/releases_count", "ReleaseController.releases_count");

  Route.post("/new_track", "ReleaseController.new_track");
  Route.get("/get_tracks", "ReleaseController.get_tracks");
  Route.post("/delete_track", "ReleaseController.delete_track");

  Route.get("/get_reports", "FinancialController.get_reports");
  Route.get("/find_report", "FinancialController.findReport");

  Route.get("/get_analytics", "AnalyticsController.get_user_analytics");
  Route.get(
    "/get_release_analytics",
    "AnalyticsController.get_release_analytics_user"
  );
  Route.get("/get_all_streams", "AnalyticsController.get_user_all_streams");
  Route.get("/get_date_streams", "AnalyticsController.get_user_date_streams");
  Route.get(
    "/get_release_date_streams",
    "AnalyticsController.get_release_date_streams_user"
  );

  Route.get("/get_links", "LinkController.get_links");
  Route.post("/edit_link", "LinkController.edit_link");
  Route.get("/get_link", "LinkController.get_link");
  Route.get("/sync_platforms", "LinkController.sync_platforms");
})
  .middleware(["auth"])
  .prefix("/user");

// admin
Route.post("/admin/register", "AdminController.register");

Route.group(() => {
  Route.post("/new_news", "AdminController.new_news");

  Route.get("/get_releases", "AdminController.get_releases");
  Route.get("/get_moderation", "AdminController.get_moderation");
  Route.get("/search", "AdminController.search");
  Route.get("/get_release_info", "AdminController.get_release_info");
  Route.post("/accept_release", "AdminController.accept_release");
  Route.post("/reject_release", "AdminController.reject_release");
  Route.post("/delete_release", "AdminController.delete_release");
  Route.get("/releases_count", "AdminController.releases_count");

  Route.get("/get_users", "AdminController.get_users");
  Route.post("/edit_user", "AdminController.edit_user");
  Route.post("/user_register", "AdminController.user_register");

  Route.get("/get_reports", "AdminController.get_reports");
  Route.get("/find_report", "AdminController.find_report");
  Route.post("/new_report", "AdminController.new_report");

  Route.get("/convert_id_to_user", "AdminController.convert_id_to_user");

  Route.get("/get_analytics", "AnalyticsController.get_admin_analytics");
  Route.get(
    "/get_release_analytics",
    "AnalyticsController.get_release_analytics_admin"
  );
  Route.get("/get_all_streams", "AnalyticsController.get_admin_all_streams");
  Route.get("/get_date_streams", "AnalyticsController.get_admin_date_streams");
  Route.get(
    "/get_release_date_streams",
    "AnalyticsController.get_release_date_streams_admin"
  );
})
  .middleware(["admin"])
  .prefix("/admin");

// 404

Route.get("*", async () => {
  return { error: 404 };
});
Route.post("*", async () => {
  return { error: 404 };
});
