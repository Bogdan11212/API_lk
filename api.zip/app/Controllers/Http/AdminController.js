"use strict";

const User = use("App/Models/User");
const News = use("App/Models/News");
const Env = use("Env");
const Release = use("App/Models/Release");
const Track = use("App/Models/Track");
const Database = use("Database");
const nodemailer = require("nodemailer");
const axios = require("axios");
const Helpers = use("Helpers");
const Financial = use("App/Models/Financial");
const Link = use("App/Models/Link");

let tg_api_url = `https://api.telegram.org/bot${Env.get(
  "BOT_TOKEN"
)}/sendMessage?chat_id=${Env.get("CHAT_ID")}&text=`;

let transporter = nodemailer.createTransport({
  host: Env.get("EMAIL_HOST"),
  port: 465,
  secure: true,
  auth: {
    user: Env.get("EMAIL_USER"),
    pass: Env.get("EMAIL_PASSWORD"),
  },
});

class AdminController {
  async register({ request, auth }) {
    if (request.input("token") != Env.get("SECRET_TOKEN"))
      return { error: 403 };
    try {
      const { username, email, name, password } = request.all();

      let user = await User.create({
        username: username,
        email: email,
        password: password,
        name: name,
        status: "admin",
      });

      let token = await auth.generate(user);

      return { error: false, token: token.token };
    } catch (e) {
      console.log(e);
      return { error: "bad login or pass" };
    }
  }

  // news

  async new_news({ request }) {
    await News.create({
      title: request.input("title"),
      body: request.input("body"),
    });

    return { error: false };
  }

  // releases

  async get_releases({ request }) {
    const { type, limit } = request.all();
    const releases = await Database.table("releases")
      .where("status", "=", type)
      .limit(limit)
      .orderBy("date", "desc");
    const count = await Database.table("releases")
      .where("status", "=", type)
      .limit(limit)
      .count("id as total")
      .orderBy("created_at", "desc");

    return { error: false, releases: releases, total: count[0].total };
  }
  async get_moderation() {
    const releases = await Database.table("releases")
      .where("status", "=", "moderation")
      .orderBy("created_at", "desc");

    return { error: false, releases: releases };
  }
  async search({ request, auth }) {
    const q = request.input("q");
    const type = request.input("type");

    const releasesJson = await Database.table("releases")
      .where("status", "=", type)
      .orderBy("date", "desc");
    let result = [];

    for (const release of releasesJson) {
      if (
        release.title.toLowerCase().includes(q.toLowerCase()) ||
        release.artists.toLowerCase().includes(q.toLowerCase())
      ) {
        result.push(release);
      }
    }

    return { error: false, releases: result, total: result.length };
  }
  async get_release_info({ request }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };

    const tracks = await Database.table("tracks").where(
      "release_id",
      "=",
      release.id
    );

    return { error: false, release: release, tracks: tracks };
  }
  async accept_release({ request, auth }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };

    release.status = "ok";
    release.upc = request.input("upc");

    let token = "";
    let symbols = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for (let i = 0; i < 6; i++) {
      token += symbols.charAt(Math.floor(Math.random() * symbols.length));
    }
    await Link.create({
      user_id: release.user_id,
      upc: release.upc,
      token: token,
    });

    await release.save();

    let text = `Администратор ${auth.user.email} принял релиз:\n\n${
      release.artists
    } - ${release.title}\nUPC: ${request.input("upc")}`;
    await axios.get(encodeURI(`${tg_api_url}${text}`));

    return { error: false };
  }
  async reject_release({ request, auth }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };

    release.status = "draft";

    await release.save();

    let text = `Администратор ${auth.user.email} отклонил релиз:\n\n${
      release.artists
    } - ${release.title}\nПричина: ${request.input("reason")}`;
    await axios.get(encodeURI(`${tg_api_url}${text}`));

    try {
      const user = await User.find(release.user_id);

      await transporter.sendMail({
        from: `"Робот ${Env.get("APP_NAME")}" <${Env.get("EMAIL_USER")}>`,
        to: `${user.email}`,
        subject: `Релиз ${release.artists} - ${release.title} не прошел модерацию.`,
        html: `Здравствуйте, ${user.name}!<br><br>Ваш релиз <b>${
          release.artists
        } - ${
          release.title
        }</b>, не прошел модерацию.<br><br> Причина: ${request.input(
          "reason"
        )}<br><br>С уважением, команда ${Env.get("APP_NAME")}.`,
      });

      return { error: false };
    } catch (e) {
      return { error: e };
    }
  }
  async delete_release({ request }) {
    try {
      const release = await Release.find(request.input("id"));

      if (!release) return { error: 404 };

      const fs = Helpers.promisify(require("fs"));
      if (release.cover) {
        try {
          await fs.unlink(Helpers.publicPath(release.cover));
        } catch {}
      }

      const tracks = await Database.table("tracks").where(
        "release_id",
        "=",
        release.id
      );

      if (tracks.length != 0) {
        for (const track of tracks) {
          let trackJs = await Track.find(track.id);

          try {
            await fs.unlink(Helpers.publicPath(track.wav));
          } catch {}

          await trackJs.delete();
        }
      }

      await release.delete();

      return { error: false };
    } catch (e) {
      return { error: e };
    }
  }

  // users
  async get_users() {
    const users = await Database.table("users").orderBy("created_at", "desc");

    return { error: false, users: users };
  }
  async edit_user({ request }) {
    try {
      const user = await User.find(request.input("id"));
      const { name, password, email, username, status, balance } =
        request.all();
      user.name = name;
      user.password = password;
      user.email = email;
      user.username = username;
      user.status = status;
      user.balance = balance;

      await user.save();
    } catch (e) {
      return { error: "Пользователь уже существует" };
    }

    return { error: false };
  }

  async user_register({ request }) {
    const { username, email, name, status } = request.all();
    let password = "";
    let symbols =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (let i = 0; i < 8; i++) {
      password += symbols.charAt(Math.floor(Math.random() * symbols.length));
    }
    try {
      let user = await User.create({
        username: username,
        email: email,
        password: password,
        name: name,
        status: status,
      });
      return { error: false, email: user.email, password: password };
    } catch {
      return { error: "Пользователь уже существует" };
    }
  }

  // finance
  async get_reports() {
    const financial = await Database.table("financials").orderBy(
      "created_at",
      "desc"
    );
    return { error: false, financial: financial };
  }
  async find_report({ request }) {
    const { year, quarter } = request.all();
    const date = new Date().getFullYear();

    if (year > date) {
      return { error: 403 };
    }
    if (quarter > 4) {
      return { error: 403 };
    }

    const financial = await Database.table("financials")
      .where("year", "=", year)
      .andWhere("quarter", "=", quarter)
      .orderBy("created_at", "desc");

    return { error: false, financial: financial };
  }
  async new_report({ request }) {
    const { year, quarter, user_id, sum } = request.all();
    const date = new Date().getFullYear();

    if (year > date) {
      return { error: 403 };
    }
    if (quarter > 4) {
      return { error: 403 };
    }

    const user = await User.find(user_id);
    if (!user) return { error: 403 };
    const validationOptions = {
      types: ["csv", "vnd.ms-excel"],
      size: "100mb",
    };
    const reportFile = request.file("file", validationOptions);
    if (!reportFile) return { error: 403 };

    let secret = "";
    let symbols =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (let i = 0; i < 30; i++) {
      secret += symbols.charAt(Math.floor(Math.random() * symbols.length));
    }
    await reportFile.move(Helpers.publicPath(`/reports/${user_id}`), {
      name: `${secret}.csv`,
      overwrite: false,
    });

    if (!reportFile.moved()) {
      return { error: coverFile.error() };
    }

    let file = `/reports/${user_id}/${secret}.csv`;

    await Financial.create({
      user_id: user_id,
      quarter: quarter,
      year: year,
      file: file,
      sum: sum,
    });

    try {
      await transporter.sendMail({
        from: `"Робот ${Env.get("APP_NAME")}" <${Env.get("EMAIL_USER")}>`,
        to: `${user.email}`,
        subject: `Отчеты за ${quarter} квартал ${year} года`,
        html: `Здравствуйте, ${
          user.name
        }!<br><br>Отчеты за ${quarter} квартал ${year} года были опубликованы в Вашем личном кабинете.<br><br>С уважением, команда ${Env.get(
          "APP_NAME"
        )}.`,
      });
    } catch {
      console.log("email error");
    }

    return { error: false };
  }

  async convert_id_to_user({ request }) {
    const { id } = request.all();

    const user = await User.find(id);

    if (!user) return { error: 404 };

    return { error: false, user: user };
  }
  async releases_count() {
    const catalog = await Database.table("releases")
      .where("status", "=", "ok")
      .count("id as total");
    const moderation = await Database.table("releases")
      .where("status", "=", "moderation")
      .count("id as total");
    const deleting = await Database.table("releases")
      .where("status", "=", "deleting")
      .count("id as total");

    return {
      error: false,
      count: {
        releases: catalog[0]["total"],
        moderation: moderation[0]["total"],
        deleting: deleting[0]["total"],
      },
    };
  }
}

module.exports = AdminController;
