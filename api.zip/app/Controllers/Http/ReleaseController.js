"use strict";

const Release = use("App/Models/Release");
const Track = use("App/Models/Track");
const Database = use("Database");
const Helpers = use("Helpers");
const axios = require("axios");
const Env = use("Env");
const nodemailer = require("nodemailer");

let tg_api_url = `https://api.telegram.org/bot${Env.get(
  "BOT_TOKEN"
)}/sendMessage?chat_id=${Env.get("CHAT_ID")}&text=`;
let transporter = nodemailer.createTransport({
  host: Env.get("EMAIL_HOST"),
  port: 465,
  secure: true,
  auth: {
    user: Env.get("EMAIL_USER"),
    pass: Env.get("EMAIL_PASSWORD"),
  },
});

class ReleaseController {
  async get_releases({ auth, request }) {
    const { type, limit } = request.all();
    const releases = await Database.table("releases")
      .where("user_id", "=", auth.user.id)
      .andWhere("status", "=", type)
      .limit(limit)
      .orderBy("created_at", "desc");
    const count = await Database.table("releases")
      .where("user_id", "=", auth.user.id)
      .andWhere("status", "=", type)
      .limit(limit)
      .count("id as total")
      .orderBy("created_at", "desc");

    return { error: false, releases: releases, total: count[0].total };
  }
  async get_release_cover({ request, auth, response }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };

    const fs = Helpers.promisify(require("fs"));

    response.header("Content-type", "image/jpeg");

    return await fs.readFile(Helpers.publicPath(release.cover));
  }
  async get_release_info({ request, auth }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };

    const tracks = await Database.table("tracks").where(
      "release_id",
      "=",
      release.id
    );

    return { error: false, release: release, tracks: tracks };
  }
  async get_release_platforms({ request, auth }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };
    if (!release.upc) return { error: 403 };

    let platforms = [];
    let url = "";
    let deezer = "";
    try {
      const { data: data } = await axios.get(
        `https://api.deezer.com/album/upc:${release.upc}`
      );
      deezer = data.link;
      if (deezer) {
        platforms.push({ name: "Deezer", link: data.link });
      }
    } catch {
      console.log("deezer error");
    }

    if (!deezer) {
      try {
        url = `https://youtubdle.com/suggestions?search=${release.title} ${release.artists}`;
        let yt = await axios.get(encodeURI(url));
        //console.log(yt.data);

        for (const video of yt.data.data) {
          if (video.snippet.description.includes("Provided to YouTube by")) {
            let link = "https://www.youtube.com/watch?v=" + video.id.videoId;

            platforms.push({ name: "YouTube", link: link });

            break;
          }
        }
      } catch (e) {
        console.log("yt error");
        //console.log(e);
      }
    } else {
      try {
        const { data: odesil } = await axios.get(
          `https://api.song.link/v1-alpha.1/links?url=${deezer}`
        );

        if (odesil.pageUrl) {
          try {
            platforms.push({
              name: "Spotify",
              link: odesil.linksByPlatform.spotify.url,
            });
          } catch {}
          try {
            platforms.push({
              name: "Яндекс Музыка",
              link: odesil.linksByPlatform.yandex.url,
            });
          } catch {}
          try {
            platforms.push({
              name: "YouTube",
              link: odesil.linksByPlatform.youtube.url,
            });
          } catch {}
          try {
            platforms.push({
              name: "YouTube Music",
              link: odesil.linksByPlatform.youtubeMusic.url,
            });
          } catch {}
          try {
            platforms.push({
              name: "Apple Music",
              link: odesil.linksByPlatform.appleMusic.url,
            });
          } catch {}
        }
      } catch {
        console.log("odesil error");
      }
    }

    try {
      platforms.sort(function (a, b) {
        const nameA = a.name.toUpperCase(); // ignore upper and lowercase
        const nameB = b.name.toUpperCase(); // ignore upper and lowercase
        if (nameA < nameB) {
          return -1;
        }
        if (nameA > nameB) {
          return 1;
        }

        // names must be equal
        return 0;
      });
    } catch (e) {}

    return { error: false, platforms: platforms };
  }
  async new_release({ auth }) {
    const release = await Release.create({
      user_id: auth.user.id,
      status: "draft",
    });

    return { error: false, release: release };
  }
  async edit_release({ auth, request }) {
    const release = await Release.find(request.input("id"));
    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };
    if (release.status != "draft") return { error: 403 };

    const validationOptions = {
      types: ["image"],
      size: "10mb",
    };

    const coverFile = request.file("cover", validationOptions);
    if (coverFile) {
      try {
        if (release.cover) {
          const fs = Helpers.promisify(require("fs"));
          await fs.unlink(Helpers.publicPath(release.cover));
        }
      } catch {}
      let secret = "";
      let symbols =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      for (let i = 0; i < 30; i++) {
        secret += symbols.charAt(Math.floor(Math.random() * symbols.length));
      }
      await coverFile.move(Helpers.publicPath(`/covers/${auth.user.id}`), {
        name: `${secret}.jpg`,
        overwrite: false,
      });

      if (!coverFile.moved()) {
        return { error: coverFile.error() };
      }

      release.cover = `/covers/${auth.user.id}/${secret}.jpg`;
    }

    const { title, artists, version, genre, date, type, comment } =
      request.all();

    release.title = title;
    release.artists = artists;
    release.version = version;
    release.genre = genre;
    release.date = date;
    release.type = type;
    release.comment = comment;

    await release.save();

    return { error: false, release: release };
  }
  async send_release({ request, auth }) {
    const release = await Release.find(request.input("id"));
    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };
    if (release.status != "draft") return { error: 403 };

    const tracks = await Database.table("tracks")
      .where("release_id", "=", release.id)
      .orderBy("created_at", "desc");
    if (tracks.length == 0)
      return { error: "Нужно добавить хотя бы один трек!" };

    if (!release.title) return { error: "Заполните все обязательные поля" };
    if (!release.artists) return { error: "Заполните все обязательные поля" };
    if (!release.cover) return { error: "Заполните все обязательные поля" };
    if (!release.genre) return { error: "Заполните все обязательные поля" };
    if (!release.date) return { error: "Заполните все обязательные поля" };
    if (!release.type) return { error: "Заполните все обязательные поля" };

    release.status = "moderation";

    await release.save();
    let text = `Пользователь ${
      auth.user.email
    } отправил релиз на модерацию:\n\n${release.artists} - ${
      release.title
    }\n\nhttps://${Env.get("URL")}/admin/music/${release.id}/view`;
    await axios.get(encodeURI(`${tg_api_url}${text}`));

    return { error: false };
  }
  async new_track({ request, auth }) {
    const release = await Release.find(request.input("id"));
    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };
    if (release.status != "draft") return { error: 403 };

    const validationOptions = {
      types: ["wav", "x-wav", "wave"],
      size: "200mb",
    };

    const wavFile = request.file("wav", validationOptions);
    let wav = "";
    if (wavFile) {
      let secret = "";
      let symbols =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      for (let i = 0; i < 30; i++) {
        secret += symbols.charAt(Math.floor(Math.random() * symbols.length));
      }
      await wavFile.move(Helpers.publicPath(`/tracks/${auth.user.id}`), {
        name: `${secret}.wav`,
        overwrite: false,
      });

      if (!wavFile.moved()) {
        return { error: wavFile.error() };
      }

      wav = `/tracks/${auth.user.id}/${secret}.wav`;
    } else {
      return { error: "Загрузите wav файл" };
    }
    const { id, title, version, artists, author, explicit, composer } =
      request.all();
    const track = await Track.create({
      release_id: id,
      wav: wav,
      title: title,
      version: version,
      artists: artists,
      author: author,
      explicit: explicit,
      composer: composer,
    });

    return { error: false, track: track };
  }
  async get_tracks({ request, auth }) {
    const release = await Release.find(request.input("id"));
    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };

    const tracks = await Database.table("tracks").where(
      "release_id",
      "=",
      release.id
    );

    return { error: false, tracks: tracks };
  }
  async delete_draft({ request, auth }) {
    const release = await Release.find(request.input("id"));
    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };
    if (release.status != "draft") return { error: 403 };

    const fs = Helpers.promisify(require("fs"));
    if (release.cover) {
      try {
        await fs.unlink(Helpers.publicPath(release.cover));
      } catch {}
    }

    const tracks = await Database.table("tracks").where(
      "release_id",
      "=",
      release.id
    );

    if (tracks.length != 0) {
      for (const track of tracks) {
        let trackJs = await Track.find(track.id);

        try {
          await fs.unlink(Helpers.publicPath(track.wav));
        } catch {}

        await trackJs.delete();
      }
    }

    await release.delete();

    return { error: false };
  }
  async delete_release({ request, auth }) {
    const release = await Release.find(request.input("id"));
    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };
    if (release.status != "ok") return { error: 403 };

    release.status = "deleting";

    await release.save();

    try {
      await transporter.sendMail({
        from: `"Робот ${Env.get("APP_NAME")}" <${Env.get("EMAIL_USER")}>`,
        to: `${auth.user.email}`,
        subject: `Релиз ${release.artists} - ${release.title} был отправлен на удаление.`,
        html: `Здравствуйте, ${auth.user.name}!<br><br>Ваш релиз <b>${
          release.artists
        } - ${
          release.title
        }</b>, был отправлен на удаление.<br><br> Если это были не вы - срочно напишите Вашему менеджеру.<br><br>С уважением, команда ${Env.get(
          "APP_NAME"
        )}.`,
      });
    } catch {
      console.log("email error");
    }

    let text = `Пользователь ${
      auth.user.email
    } отправил релиз на удаление:\n\n${release.artists} - ${
      release.title
    }\nUPC: ${release.upc}\n\nhttps://${Env.get("URL")}/admin/music/deleting`;
    await axios.get(encodeURI(`${tg_api_url}${text}`));

    return { error: false };
  }
  async delete_track({ request, auth }) {
    const track = await Track.find(request.input("id"));
    if (!track) return { error: 404 };
    const release = await Release.find(track.release_id);
    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };
    if (release.status != "draft") return { error: 403 };
    const fs = Helpers.promisify(require("fs"));
    try {
      await fs.unlink(Helpers.publicPath(track.wav));
    } catch {}

    await track.delete();

    return { error: false };
  }
  async search({ request, auth }) {
    const q = request.input("q").toLowerCase();
    const type = request.input("type");

    const releasesJson = await Database.table("releases")
      .where("user_id", "=", auth.user.id)
      .andWhere("status", "=", type)
      .orderBy("date", "desc");
    let result = [];

    for (const release of releasesJson) {
      if (
        release.title.toLowerCase().includes(q) ||
        release.artists.toLowerCase().includes(q)
      ) {
        result.push(release);
      }
    }

    return { error: false, releases: result, total: result.length };
  }
  async releases_count({ auth }) {
    const catalog = await Database.table("releases")
      .where("user_id", "=", auth.user.id)
      .andWhere("status", "=", "ok")
      .count("id as total");
    const moderation = await Database.table("releases")
      .where("user_id", "=", auth.user.id)
      .andWhere("status", "=", "moderation")
      .count("id as total");
    const deleting = await Database.table("releases")
      .where("user_id", "=", auth.user.id)
      .andWhere("status", "=", "deleting")
      .count("id as total");
    const drafts = await Database.table("releases")
      .where("user_id", "=", auth.user.id)
      .andWhere("status", "=", "draft")
      .count("id as total");

    return {
      error: false,
      count: {
        releases: catalog[0]["total"],
        drafts: drafts[0]["total"],
        moderation: moderation[0]["total"],
        deleting: deleting[0]["total"],
      },
    };
  }
}

module.exports = ReleaseController;
