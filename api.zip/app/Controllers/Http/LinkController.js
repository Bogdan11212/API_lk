"use strict";

const Link = use("App/Models/Link");
const Release = use("App/Models/Release");
const User = use("App/Models/User");
const Database = use("Database");
const axios = require("axios");

class LinkController {
  async sync() {
    const releases = await Database.table("releases").where(
      "status",
      "=",
      "ok"
    );

    for (const release of releases) {
      try {
        let token = "";
        let symbols = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (let i = 0; i < 6; i++) {
          token += symbols.charAt(Math.floor(Math.random() * symbols.length));
        }
        await Link.create({
          user_id: release.user_id,
          upc: release.upc,
          token: token,
          theme: "light",
        });
      } catch {
        continue;
      }
    }

    return { error: false };
  }

  async sync_platforms({ request, auth }) {
    const link = await Link.findBy("token", request.input("token"));
    if (!link) return { error: 404 };
    if (link.user_id != auth.user.id) return { error: 403 };

    let deezer = "";
    try {
      const { data: data } = await axios.get(
        `https://api.deezer.com/album/upc:${link.upc}`
      );
      deezer = data.link;
      if (deezer) {
        link.deezer = deezer;
      }
    } catch {
      console.log("deezer error");
    }

    if (deezer) {
      try {
        const { data: odesil } = await axios.get(
          `https://api.song.link/v1-alpha.1/links?url=${deezer}`
        );

        if (odesil.pageUrl) {
          try {
            link.spotify = odesil.linksByPlatform.spotify.url;
          } catch {}
          try {
            link.yandex = odesil.linksByPlatform.yandex.url;
          } catch {}
          try {
            link.youtube = odesil.linksByPlatform.youtubeMusic.url;
          } catch {}
          try {
            link.apple = odesil.linksByPlatform.appleMusic.url;
          } catch {}
        }
      } catch {
        console.log("odesil error");
      }
      await link.save();
      console.log(link);
    }
    return { error: false };
  }

  async get_link_web({ request }) {
    const link = await Link.findBy("token", request.input("id"));

    if (!link) return { error: 404 };

    const release = await Release.findBy("upc", link.upc);
    let linkJson = {};
    if (release) {
      linkJson = {
        release: {
          cover: release.cover,
          title: release.title,
          artists: release.artists,
        },
        link: { id: link.id, token: link.token },
        links: {
          apple: link.apple,
          vk: link.vk,
          yandex: link.yandex,
          youtube: link.youtube,
          spotify: link.spotify,
          deezer: link.deezer,
        },
        socials: {
          vk: link.social_vk,
          telegram: link.social_telegram,
          zen: link.social_zen,
          tiktok: link.social_tiktok,
          youtube: link.social_youtube,
        },
        pixels: {
          vk: link.vk_pixel,
        },
        theme: link.theme,
      };
    } else {
      const deleteLink = await Link.find(link.id);
      await deleteLink.delete();
      return { error: 404 };
    }

    return { error: false, link: linkJson };
  }
  async next_links() {
    const linksJson = await Database.table("links");

    let links = [];

    for (const link of linksJson) {
      const release = await Release.findBy("upc", link.upc);

      if (release) {
        links.push({
          id: link.id,
          token: link.token,
        });
      } else {
        const deleteLink = await Link.find(link.id);
        await deleteLink.delete();
      }
    }

    return { error: false, links: links };
  }
  async get_links({ auth }) {
    const linksJson = await Database.table("links").where(
      "user_id",
      "=",
      auth.user.id
    );

    let links = [];

    for (const link of linksJson) {
      const release = await Release.findBy("upc", link.upc);

      if (release) {
        links.push({
          release: {
            cover: release.cover,
            title: release.title,
            artists: release.artists,
            upc: release.upc,
            date: release.date,
          },
          link: { id: link.id, token: link.token },
        });
      } else {
        const deleteLink = await Link.find(link.id);
        await deleteLink.delete();
      }
    }

    return { error: false, links: links };
  }
  async edit_link({ auth, request }) {
    const link = await Link.find(request.input("id"));

    if (!link) return { error: 404 };
    if (link.user_id != auth.user.id) return { error: 403 };

    if (request.input("token")) {
      link.token = request.input("token");
    }

    link.apple = request.input("apple");
    link.vk = request.input("vk");
    link.yandex = request.input("yandex");
    link.youtube = request.input("youtube");
    link.spotify = request.input("spotify");
    link.deezer = request.input("deezer");

    link.social_vk = request.input("social_vk");
    link.social_telegram = request.input("social_telegram");
    link.social_zen = request.input("social_zen");
    link.social_tiktok = request.input("social_tiktok");
    link.social_youtube = request.input("social_youtube");

    link.vk_pixel = request.input("vk_pixel");

    if (request.input("theme") != "light" && request.input("theme") != "dark") {
      return { error: 400 };
    }
    link.theme = request.input("theme");

    await link.save();

    return { error: false };
  }
  async get_link({ request, auth }) {
    const link = await Link.find(request.input("id"));

    if (!link) return { error: 404 };
    if (link.user_id != auth.user.id) return { error: 403 };

    const release = await Release.findBy("upc", link.upc);
    let linkJson = {};
    if (release) {
      linkJson = {
        release: {
          cover: release.cover,
          title: release.title,
          artists: release.artists,
        },
        link: { id: link.id, token: link.token },
        links: {
          apple: link.apple,
          vk: link.vk,
          yandex: link.yandex,
          youtube: link.youtube,
          spotify: link.spotify,
          deezer: link.deezer,
        },
        socials: {
          vk: link.social_vk,
          telegram: link.social_telegram,
          zen: link.social_zen,
          tiktok: link.social_tiktok,
          youtube: link.social_youtube,
        },
        pixels: {
          vk: link.vk_pixel,
        },
        theme: link.theme,
      };
    } else {
      const deleteLink = await Link.find(link.id);
      await deleteLink.delete();
      return { error: 404 };
    }

    return { error: false, link: linkJson };
  }
}

module.exports = LinkController;
