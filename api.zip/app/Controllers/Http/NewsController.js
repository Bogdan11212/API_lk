"use strict";

const Database = use("Database");
const News = use("App/Models/News");

class NewsController {
  async get_news() {
    const news = await Database.table("news").orderBy("created_at", "desc");

    return { error: false, news: news };
  }
  async get_news_by_id({ request }) {
    const news = await News.find(request.input("id"));
    if (!news) return { error: 404 };
    return { error: false, news: news };
  }
}

module.exports = NewsController;
