"use strict";

const Financial = use("App/Models/Financial");
const Database = use("Database");

class FinancialController {
  async get_reports({ auth }) {
    const financial = await Database.table("financials")
      .where("user_id", "=", auth.user.id)
      .orderBy("created_at", "desc");

    return { error: false, financial: financial };
  }
  async findReport({ request, auth }) {
    const { year, quarter } = request.all();
    const date = new Date().getFullYear();

    if (year > date) {
      return { error: 403 };
    }
    if (quarter > 4) {
      return { error: 403 };
    }

    const financial = await Database.table("financials")
      .where("year", "=", year)
      .andWhere("quarter", "=", quarter)
      .andWhere("user_id", "=", auth.user.id)
      .orderBy("created_at", "desc");

    return { error: false, financial: financial };
  }
}

module.exports = FinancialController;
