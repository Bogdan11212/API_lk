"use strict";

const axios = require("axios");
const Env = use("Env");

let tg_api_url = `https://api.telegram.org/bot${Env.get(
  "BOT_TOKEN"
)}/sendMessage`;

function sTest(s) {
  if (s === "") return false;
  let count = 0;
  for (let i = 0; i < s.length; i++) {
    if (s[i] === " ") ++count;
  }

  if (count === s.length) return false;

  return true;
}

class PublicController {
  async feedback({ request }) {
    const { name, email, message } = request.all();

    if (
      !/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(
        email
      )
    ) {
      return { error: "incorrect email" };
    }

    if (!sTest(name)) return { error: "name is required" };
    if (!sTest(message)) return { error: "message is required" };

    let text = `Новое сообщение:\n\nИмя: ${name}\nEmail: ${email}\nСообщение: ${message}`;

    try {
      await axios.post(tg_api_url, { chat_id: Env.get("CHAT_ID"), text: text });
    } catch (e) {
      return { error: e };
    }

    return { error: false };
  }
  async questionnaire({ request }) {
    const { name, email, country, city, social, tracks, catalog, genres } =
      request.all();

    if (!sTest(name)) return { error: "name is required" };
    if (!sTest(email)) return { error: "email is required" };
    if (
      !/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(
        email
      )
    ) {
      return { error: "incorrect email" };
    }

    if (!sTest(social)) return { error: "social is required" };
    if (!sTest(tracks)) return { error: "tracks is required" };
    if (!sTest(catalog)) return { error: "catalog is required" };
    if (!/^\d+$/.test(catalog)) return { error: "incorrect catalog (number)" };

    if (!sTest(genres)) return { error: "genres is required" };

    let text = `Новая заявка:\n\nИмя: ${name}\nEmail: ${email}\nМесто проживания: ${country}, ${city}\nСоциальные сети: ${social}\nТреки: ${tracks}\nВсего треков: ${catalog}\nЖанры: ${genres}`;

    await axios.post(tg_api_url, { chat_id: Env.get("CHAT_ID"), text: text });

    return { error: false };
  }
}

module.exports = PublicController;
