"use strict";

const Database = use("Database");
const Env = use("Env");
const Analytics = use("App/Models/Analytics");
const Stream = use("App/Models/Stream");
const User = use("App/Models/User");
const Release = use("App/Models/Release");
const axios = use("axios");

let tg_api_url = `https://api.telegram.org/bot${Env.get(
  "BOT_TOKEN"
)}/sendMessage?chat_id=${Env.get("CHAT_ID")}&text=`;

class AnalyticsController {
  async get_new_analytics({ request }) {
    if (request.header("token") != Env.get("SECRET_TOKEN"))
      return { error: 403 };
    try {
      const data = request.input("data");

      for (const track of data) {
        const release = await Release.findBy("upc", track.upc);
        if (!release) {
          console.log("Релиз не найден");
        } else {
          const analytics = await Analytics.findBy("upc", track.upc);
          if (analytics) {
            analytics.pay_streams = track.pay_streams;
            analytics.all_streams = track.streams;

            await analytics.save();
          } else {
            await Analytics.create({
              user_id: release.user_id,
              release_id: release.id,
              title: track.album,
              artists: track.artist,
              upc: track.upc,
              pay_streams: track.pay_streams,
              all_streams: track.streams,
            });
          }
        }
      }

      // last
      let text = `Статистика в личном кабинете обновлена!`;
      await axios.get(encodeURI(`${tg_api_url}${text}`));

      return { error: false };
    } catch (error) {
      let text = `При обновлении статистики случилась ошибка: ${error}`;
      await axios.get(encodeURI(`${tg_api_url}${text}`));
      return { error: error };
    }
  }
  async get_new_streams({ request }) {
    if (request.header("token") != Env.get("SECRET_TOKEN"))
      return { error: 403 };
    try {
      const data = request.input("data");

      for (const track of data) {
        const release = await Release.findBy("upc", track.upc);
        if (!release) {
          console.log("Релиз не найден");
        } else {
          const stream = await Database.table("streams")
            .where("upc", "=", track.upc)
            .andWhere("date", "=", track.report_date);
          if (stream.length === 0) {
            await Stream.create({
              user_id: release.user_id,
              release_id: release.id,
              title: track.album,
              artists: track.artist,
              upc: track.upc,
              pay_streams: track.pay_streams,
              all_streams: track.streams,
              date: track.report_date,
            });
          }
        }
      }

      // last
      let text = `Статистика по датам в личном кабинете обновлена!`;
      await axios.get(encodeURI(`${tg_api_url}${text}`));

      return { error: false };
    } catch (error) {
      let text = `При обновлении статистики по датам случилась ошибка: ${error}`;
      await axios.get(encodeURI(`${tg_api_url}${text}`));
      return { error: error };
    }
  }
  // user
  async get_user_analytics({ auth, request }) {
    const analytics = await Database.table("analytics")
      .where("user_id", "=", auth.user.id)
      .orderBy("all_streams", "desc")
      .limit(request.input("limit"));

    return { error: false, analytics: analytics };
  }
  async get_user_date_streams({ auth, request }) {
    let orderBy = request.input("orderBy");
    if (!orderBy) orderBy = "asc";
    const streams = await Database.table("streams")
      .where("user_id", "=", auth.user.id)
      .orderBy("date", orderBy)
      .limit(request.input("limit"));

    return { error: false, streams: streams };
  }
  async get_user_all_streams({ auth }) {
    const analytics = await Database.table("analytics")
      .where("user_id", "=", auth.user.id)
      .orderBy("updated_at", "desc");

    let all_streams = 0;
    let pay_streams = 0;

    for (const anal of analytics) {
      all_streams = all_streams + anal.all_streams;
      pay_streams = pay_streams + anal.pay_streams;
    }

    return { error: false, all_streams: all_streams, pay_streams: pay_streams };
  }
  async get_release_analytics_user({ auth, request }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };

    const analytics = await Database.table("analytics")
      .where("user_id", "=", auth.user.id)
      .andWhere("release_id", "=", release.id)
      .orderBy("updated_at", "desc")
      .limit(request.input("limit"));

    return { error: false, analytics: analytics };
  }
  async get_release_date_streams_user({ request, auth }) {
    const release = await Release.find(request.input("id"));
    let orderBy = request.input("orderBy");
    if (!orderBy) orderBy = "asc";

    if (!release) return { error: 404 };
    if (release.user_id != auth.user.id) return { error: 403 };

    const streams = await Database.table("streams")
      .where("release_id", "=", release.id)
      .orderBy("date", orderBy)
      .limit(request.input("limit"));

    return { error: false, streams: streams };
  }

  // admin
  async get_admin_analytics({ request }) {
    const analytics = await Database.table("analytics")
      .orderBy("all_streams", "desc")
      .limit(request.input("limit"));

    return { error: false, analytics: analytics };
  }
  async get_admin_date_streams({ request }) {
    let orderBy = request.input("orderBy");
    if (!orderBy) orderBy = "asc";
    const streams = await Database.table("streams")
      .orderBy("date", orderBy)
      .limit(request.input("limit"));

    return { error: false, streams: streams };
  }
  async get_release_date_streams_admin({ request }) {
    const release = await Release.find(request.input("id"));
    let orderBy = request.input("orderBy");
    if (!orderBy) orderBy = "asc";
    if (!release) return { error: 404 };

    const streams = await Database.table("streams")
      .where("release_id", "=", release.id)
      .orderBy("date", orderBy)
      .limit(request.input("limit"));

    return { error: false, streams: streams };
  }

  async get_admin_all_streams() {
    const analytics = await Database.table("analytics").orderBy(
      "updated_at",
      "desc"
    );

    let all_streams = 0;
    let pay_streams = 0;

    for (const anal of analytics) {
      all_streams = all_streams + anal.all_streams;
      pay_streams = pay_streams + anal.pay_streams;
    }

    return { error: false, all_streams: all_streams, pay_streams: pay_streams };
  }
  async get_release_analytics_admin({ request }) {
    const release = await Release.find(request.input("id"));

    if (!release) return { error: 404 };

    const analytics = await Database.table("analytics")
      .where("release_id", "=", release.id)
      .orderBy("updated_at", "desc")
      .limit(request.input("limit"));

    return { error: false, analytics: analytics };
  }
}

module.exports = AnalyticsController;
